<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>NEWSPAPER</title>
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.5/umd/popper.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/index.css">

  </head>

  <body>
    <div class="navbar1">
      <ul class="nav nav-pills">
        <li class="nav-item">
          <a class="nav-link active" href="#">Accueil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Qui sommes-nous</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contacts</a>
        </li>
      </ul>
    </div>

    <div class="container">

      <div class="header">

        <div class="banner">
              <img class="logosrc"  src="http://www.getricheducation.com/wp-content/uploads/2015/01/NBC_News_2013_logo.png" alt="">
        </div>

        <div class="navbar2">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="#">Santés<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Téchnologies</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Politiques</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Economies</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Musiques</a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Artistiques
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Dessins</a>
                    <a class="dropdown-item" href="#">Bande dessiné</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Tout le reste</a>
                  </div>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        <div class="container">
          <div class="corps">
            <div class="row">
              <div class="leftside col-md-8 col-sm-12">

                <div class="articleprincipal">
                  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img class="d-block w-100" src="images/bouteille..jpg" alt="First slide">
                        <div class="carousel-caption d-none d-md-block">
                          <h3>TITRE 1</h3>
                          <p>Description d'article</p>
                        </div>
                      </div>
                      <div class="carousel-item">
                        <img class="d-block w-100" src="images/luzingu.jpg" alt="Second slide">
                        <div class="carousel-caption d-none d-md-block">
                          <h3>TITRE 2</h3>
                          <p>Description d'article</p>
                        </div>
                      </div>
                      <div class="carousel-item">
                        <img class="d-block w-100" src="images/test0002.png" alt="Third slide">
                        <div class="carousel-caption d-none d-md-block">
                          <h3>TITRE 3</h3>
                          <p>Description d'article</p>
                        </div>
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>

                <div class="middle row">
                  <section class="categories">
                    <article class="un">
                      <div class="card">
                        <div class="card-header">
                          <h4>Santé</h4>
                        </div>
                        <div class="card-body">
                          <span>by KALUMVUATI Duramana  JUNE 25, 2017 </span>

                          <div class="card-group">
                            <div class="card-deck">
                              <div class="card">
                                <img class="card-img-top" src="images/IMG_0035.JPG" alt="Card image cap">
                                <div class="card-body">
                                  <h4 class="card-title">Cube Cinema 4D</h4>
                                  <p class="card-text">La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.</p>
                                  <a href="#" class="btn btn-success">Plus</a>
                                </div>
                              </div>

                              <div class="card">
                                <img class="card-img-top" src="images/bouteille..jpg" alt="Card image cap">
                                <div class="card-body">
                                  <h4 class="card-title">Bouteille C4D</h4>
                                  <p class="card-text">La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.</p>
                                  <a href="#" class="btn btn-success">Plus</a>
                                </div>
                              </div>
                            </div>
                        </div>
                        </div>
                      </div>
                    </article>

                    <article class="deux">
                      <div class="card">
                        <div class="card-header">
                          <h4>Santé</h4>
                        </div>
                        <div class="card-body">
                          <span>by KALUMVUATI Duramana  JUNE 25, 2017 </span>

                          <div class="card-group">
                            <div class="card-deck">
                              <div class="card">
                                <img class="card-img-top" src="images/IMG_0035.JPG" alt="Card image cap">
                                <div class="card-body">
                                  <h4 class="card-title">Cube Cinema 4D</h4>
                                  <p class="card-text">La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.</p>
                                  <a href="#" class="btn btn-success">Plus</a>
                                </div>
                              </div>

                              <div class="card">
                                <img class="card-img-top" src="images/bouteille..jpg" alt="Card image cap">
                                <div class="card-body">
                                  <h4 class="card-title">Bouteille C4D</h4>
                                  <p class="card-text">La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.</p>
                                  <a href="#" class="btn btn-success">Plus</a>
                                </div>
                              </div>
                            </div>
                        </div>
                        </div>
                      </div>
                    </article>
                    <article class="trois"></article>
                    <article class="quatre">
                      <div class="card">
                        <div class="card-header">
                          <h4>Santé</h4>
                        </div>
                        <div class="card-body">
                          <span>by KALUMVUATI Duramana  JUNE 25, 2017 </span>

                          <div class="card-group">
                            <div class="card-deck">
                              <div class="card">
                                <img class="card-img-top" src="images/IMG_0035.JPG" alt="Card image cap">
                                <div class="card-body">
                                  <h4 class="card-title">Cube Cinema 4D</h4>
                                  <p class="card-text">La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.</p>
                                  <a href="#" class="btn btn-success">Plus</a>
                                </div>
                              </div>

                              <div class="card">
                                <img class="card-img-top" src="images/bouteille..jpg" alt="Card image cap">
                                <div class="card-body">
                                  <h4 class="card-title">Bouteille C4D</h4>
                                  <p class="card-text">La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.La santé de français est en train de perdre son évolution vis à vis à l'uniion Européenne.</p>
                                  <a href="#" class="btn btn-success">Plus</a>
                                </div>
                              </div>
                            </div>
                        </div>
                        </div>
                      </div>
                    </article>
                  </section>
                </div>
                <div class="down"></div>
              </div>
              <div class="rightside col-md-4 col-sm-12"></div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <div class="container">
      <div class="pagination">
        <nav aria-label="Page navigation example">
          <ul class="pagination">
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
              </a>
            </li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
              <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <div class="container">
      <div class=" footer">

      </div>
    </div>

  </body>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" ></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" ></script>

</html>
